/*
    Aufgabe 3) Rekursion - Blumenmuster mit Kreisbögen
*/
public class Aufgabe3 {
    
    private static void drawArcPattern(int x, int y, int radius) {
        // TODO: Implementieren Sie hier Ihre Lösung für die Methode
    }
    
    public static void main(String[] args) {
        // TODO: Implementieren Sie hier Ihre Lösung für die Angabe
    }
}




